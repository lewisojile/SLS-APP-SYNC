const CREATE_PROGRAM = "createProgram";
const LIST_PROGRAMS = "listPrograms";
const GET_PROGRAM = "getProgram";

exports.ADMIN_MUTATION_ACTIONS = {
  CREATE_PROGRAM,
  LIST_PROGRAMS,
  GET_PROGRAM,
};
